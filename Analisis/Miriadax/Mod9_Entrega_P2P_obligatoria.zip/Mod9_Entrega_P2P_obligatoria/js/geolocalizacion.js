var map, lat, lng, puntoInicial;
var ruta = [];

$(function()
{

  //boton de compactar
  $("#btnCompactar").on("click", function()
  {

    map = new GMaps(
    { 
      el: '#map',
      lat: puntoInicial[0],
      lng: puntoInicial[1],
    });

    // punto inicial
    map.addMarker({ lat: puntoInicial[0], lng: puntoInicial[1] });

    // punto final
    map.addMarker({ lat: ruta[ruta.length-2], lng: ruta[ruta.length-1] });
    
    map.drawRoute(
    {
      origin: [ puntoInicial[0],  puntoInicial[1] ],        
      destination: [ ruta[ruta.length-2], ruta[ruta.length-1] ],
      travelMode: 'driving',
      strokeColor: '#000000',
      strokeOpacity: 0.6,
      strokeWeight: 5
    });

  })


  function enlazarMarcador(e)
  {

   // muestra ruta entre marcas anteriores y actuales
    map.drawRoute(
    {
      // origen en coordenadas anteriores
      origin: [lat, lng],  
      // destino en coordenadas del click o toque actual
      destination: [e.latLng.lat(), e.latLng.lng()],
      travelMode: 'driving',
      strokeColor: '#000000',
      strokeOpacity: 0.6,
      strokeWeight: 5
    });

    // guarda coords para marca siguiente
    lat = e.latLng.lat();   
    lng = e.latLng.lng();

    // pone marcador en mapa
    map.addMarker({ lat: lat, lng: lng});  

    ruta.push(lat, lng);
    localStorage.ruta = JSON.stringify(ruta);

  };

  function geolocalizar()
  {

    /* variable de almacenamiento local */      
    localStorage.ruta = localStorage.ruta || JSON.stringify(ruta);   
    ruta = JSON.parse(localStorage.ruta);   


    GMaps.geolocate(
    {
      success: function(position)
      {
        // guarda coords en lat y lng
        lat = position.coords.latitude;  
        lng = position.coords.longitude;

        puntoInicial = [lat, lng];

        if (ruta.length == 0) 
        { 
            ruta = [lat, lng];                      
        } 


        // muestra mapa centrado en coords [lat, lng]
        map = new GMaps(
        {  
          el: '#map',
          lat: lat,
          lng: lng,
          click: enlazarMarcador,
          tap: enlazarMarcador
        });

        map.addMarker({ lat: lat, lng: lng});  // marcador en [lat, lng]
      },

      error: function(error) { alert('Geolocalización falla: '+error.message); },
      not_supported: function(){ alert("Su navegador no soporta geolocalización"); },

    });
  };

  geolocalizar();

});
    // Declaro mis variables de uso general (globales)
    var map, lat, lng;
    var ruta = [];

    // Utilzo la Función Ready para poder acceder al DOM ('#map')
    $(function() {

      // Compruebo que localstorage.rutas existe
      if (localStorage.ruta) {

        ruta = JSON.parse(localStorage.ruta); // Extrae las rutas guardadas
        // Creo mi mapa centrado en la primera posición
        lat = ruta[0].lat;
        lng = ruta[0].lng;
        crearMapa(lat, lng);
        // Enlaza todos los marcadores de ruta
        for (var i = 1; i < ruta.length; i++) {
          // Preparo las posiciones
          var latOrigen = ruta[i - 1].lat;
          var lngOrigen = ruta[i - 1].lng;
          var latDestino = ruta[i].lat;
          var lngDestino = ruta[i].lng;
          // Llamo a la función trazarRuta
          trazarRuta(latOrigen, lngOrigen, latDestino, lngDestino);
        }

      } else {
        // Mando a geolocalizar
        geolocalizar();
      }

      /***************** Funciones ********************/
      // Mi función que geolocaliza, crea el mapa y pone el marcador
      function geolocalizar() {
        GMaps.geolocate({
          success: function(position) {
            lat = position.coords.latitude;  // guarda coords en lat y lng
            lng = position.coords.longitude;
            ruta.push({lat: lat, lng: lng});
            localStorage.ruta = JSON.stringify(ruta);

            crearMapa(lat, lng); // Crea el mapa centrado en lat, lng

          },
          error: function(error) { alert('Geolocalización falla: '+error.message); },
          not_supported: function(){ alert("Su navegador no soporta geolocalización"); },
        });
      };

      // Mi función que crea el mapa y pone el marcador en posicion
      function crearMapa(lat, lng) {
        map = new GMaps({  // muestra mapa centrado en coords [lat, lng]
          el: '#map',
          lat: lat,
          lng: lng,
          click: enlazarMarcador,
          tap: enlazarMarcador
        });
        map.addMarker({lat: lat, lng: lng});  // pone marcador en mapa
      }

      // Mi función que enlaza marcadores
      function enlazarMarcador(e) {
        var latOrigen = lat;
        var lngOrigen = lng;
        var latDestino = e.latLng.lat();
        var lngDestino = e.latLng.lng();
        trazarRuta(latOrigen, lngOrigen, latDestino, lngDestino);
        lat = latDestino;
        lng = lngDestino;
        ruta.push({lat: lat, lng: lng});
        localStorage.ruta = JSON.stringify(ruta);
      };

      function trazarRuta(latOrigen, lngOrigen, latDestino, lngDestino) {
        map.drawRoute({
          origin: [latOrigen, lngOrigen],  // origen en coordenadas anteriores
          destination: [latDestino, lngDestino],
          travelMode: 'walking',
          strokeColor: '#000000',
          strokeOpacity: 0.6,
          strokeWeight: 5
        });
        map.addMarker({lat: latDestino, lng: lngDestino});  // pone marcador en mapa
      }
	  $("#boton").on("click", function () {	// borra los marcadores
		 if (window.confirm("Si da aceptar va a borrar todos sus marcadores")) {
		 geolocalizar();
		 //localStorage.ruta = JSON.parse(ruta);
		 ruta.splice(0,ruta.length);		 
		 //localStorage.ruta = JSON.stringify(ruta);
	     }
	  })

    });